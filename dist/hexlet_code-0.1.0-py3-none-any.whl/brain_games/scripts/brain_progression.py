#!/usr/bin/env python
from brain_games.games.Progression import main

if __name__ == '__main__':
    main()
