#!/usr/bin/env python
from brain_games.games.Calc import main

if __name__ == '__main__':
    main()
